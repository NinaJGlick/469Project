# fileshare

A small, security-focused Flask service for uploading files to local disk and downloading them again.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export FILESHARE_API_TOKENS="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export FILESHARE_DATA_DIR=/var/lib/fileshare        # absolute path recommended

gunicorn --bind 127.0.0.1:8000 --workers 2 wsgi:app
```

```bash
# Upload
curl -H "Authorization: Bearer $FILESHARE_API_TOKENS" -F "file=@report.pdf" http://127.0.0.1:8000/files
# -> 201 {"id": "9138d2…", "filename": "report.pdf", "download_url": "/files/9138d2…", …}

# Download
curl -OJ -H "Authorization: Bearer $FILESHARE_API_TOKENS" http://127.0.0.1:8000/files/<id>
```

| Method | Path          | Auth | Description                                   |
|--------|---------------|------|-----------------------------------------------|
| POST   | `/files`      | yes  | Multipart upload, field name `file`           |
| GET    | `/files/<id>` | yes  | Download by ID (always as an attachment)      |
| GET    | `/healthz`    | no   | Liveness probe                                |

## Configuration (environment variables)

| Variable                      | Default       | Notes                                                   |
|-------------------------------|---------------|---------------------------------------------------------|
| `FILESHARE_API_TOKENS`        | *(required)*  | Comma-separated bearer tokens, each ≥ 32 chars. The app refuses to start without them (fail closed). Multiple tokens allow rotation. |
| `FILESHARE_DATA_DIR`          | `./data`      | Holds `uploads/` and the SQLite metadata DB             |
| `FILESHARE_MAX_UPLOAD_BYTES`  | `10485760`    | Per-file limit                                          |
| `FILESHARE_LOG_LEVEL`         | `INFO`        |                                                         |

## Tests

```bash
python -m unittest discover -s tests -v
```

## Security design

| Threat | Mitigation |
|---|---|
| Path traversal / overwrite | Files are stored under a server-generated random ID with no extension. The client's filename never touches a filesystem path. Download IDs must match `[0-9a-f]{32}` before any lookup. |
| Unauthorized access | Every upload/download requires a bearer token, compared in constant time against SHA-256 digests. Plaintext tokens are dropped from app config after startup. |
| Malicious file types / stored XSS | Extension allowlist **plus** content verification (magic numbers for binary types, strict UTF-8 and no NUL bytes for text). Downloads use a server-chosen `Content-Type`, `Content-Disposition: attachment`, `nosniff`, and a locked-down CSP, so uploads are never rendered in your origin. |
| Resource exhaustion | Request-level `MAX_CONTENT_LENGTH` and a per-file streaming limit enforced while writing. |
| Partial / corrupt files | Streamed to a private temp file, `fsync`ed, then atomically renamed only after validation passes. Failed uploads leave nothing behind; stale temp files are purged at startup. |
| Disk permissions | Data directories `0700`, files `0600`. |
| Information leakage | JSON errors only; unexpected exceptions are logged server-side and return a generic 500. No file listing endpoint. |
| SQL injection | Parameterised queries only. |

## Deploying for production

These are outside the app's scope but matter:

- **Terminate TLS** at a reverse proxy (nginx, Caddy, a load balancer) and add `Strict-Transport-Security` there. Tokens are sent in headers and must not travel over plain HTTP.
- **Rate-limit** at the proxy (or add Flask-Limiter) to slow token guessing and upload floods. Set the proxy's body-size limit to match `FILESHARE_MAX_UPLOAD_BYTES`.
- **Run as an unprivileged user** and keep `FILESHARE_DATA_DIR` on its own volume with quotas/monitoring, since disk fill is the main availability risk.
- **Back up** both `uploads/` and `files.sqlite3` together.
- If you serve behind a proxy and need real client IPs in logs, wrap the app with `werkzeug.middleware.proxy_fix.ProxyFix` configured for exactly the number of proxies you have.
- If files might be hostile (PDFs especially can carry exploits aimed at viewers), add antivirus scanning before accepting them.

## Known limitations / next steps

- Authentication is a shared-token scheme with no per-user ownership: anyone with a valid token can fetch any file whose ID they know (IDs are 128-bit random, so they cannot be guessed). For multi-tenant use, add per-user identity and store an `owner` column.
- No delete or listing endpoint, by design. Add them with the same `require_auth` decorator if needed.
- Local-disk storage only; `FileStore` is the single seam to swap for S3 or similar.
