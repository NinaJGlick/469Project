"""HTTP endpoints."""
from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request, send_file, url_for
from werkzeug.exceptions import NotFound

from .auth import require_auth
from .storage import FileStore
from .validation import UploadRejected, parse_filename

bp = Blueprint("files", __name__)


def _store() -> FileStore:
    return current_app.extensions["filestore"]


@bp.get("/healthz")
def healthz():
    """Unauthenticated liveness probe; exposes nothing."""
    return jsonify(status="ok")


@bp.post("/files")
@require_auth
def upload_file():
    """Upload one file via multipart/form-data field ``file``."""
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        raise UploadRejected("Multipart field 'file' is required.", 400)

    display_name, extension = parse_filename(upload.filename)
    record = _store().save(upload.stream, display_name, extension)
    current_app.logger.info(
        "Stored upload id=%s size=%d type=%s", record.id, record.size, record.content_type
    )

    location = url_for("files.download_file", file_id=record.id)
    response = jsonify(
        id=record.id,
        filename=record.original_name,
        content_type=record.content_type,
        size=record.size,
        sha256=record.sha256,
        created_at=record.created_at,
        download_url=location,
    )
    response.status_code = 201
    response.headers["Location"] = location
    return response


@bp.get("/files/<file_id>")
@require_auth
def download_file(file_id: str):
    """Download a previously uploaded file by its ID."""
    store = _store()
    record = store.get(file_id)
    if record is None:
        raise NotFound("File not found.")

    path = store.path_for(record.id)
    if not path.is_file():
        current_app.logger.error("Metadata exists but file is missing: id=%s", record.id)
        raise NotFound("File not found.")

    # Content type comes from our allowlist (not the client), and the file is
    # always sent as an attachment so browsers never render it in our origin.
    return send_file(
        path,
        mimetype=record.content_type,
        as_attachment=True,
        download_name=record.original_name,
        conditional=True,
    )
