import io
import re
import tempfile
import unittest
from pathlib import Path

from fileshare import ConfigError, create_app

TOKEN = "a-test-token-that-is-definitely-long-enough"
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
MAX_UPLOAD = 1024


class AppTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.data_dir = Path(self._tmp.name)
        self.app = create_app(
            {
                "TESTING": True,
                "DATA_DIR": self.data_dir,
                "API_TOKENS": [TOKEN],
                "MAX_UPLOAD_BYTES": MAX_UPLOAD,
                "LOG_LEVEL": "CRITICAL",
            }
        )
        self.client = self.app.test_client()

    def upload(self, name, data, token=TOKEN):
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        return self.client.post(
            "/files",
            data={"file": (io.BytesIO(data), name)},
            headers=headers,
            content_type="multipart/form-data",
        )

    def auth(self):
        return {"Authorization": f"Bearer {TOKEN}"}


class RoundTripTests(AppTestCase):
    def test_upload_then_download(self):
        resp = self.upload("photo.PNG", PNG)
        self.assertEqual(resp.status_code, 201)
        body = resp.get_json()
        self.assertRegex(body["id"], r"^[0-9a-f]{32}$")
        self.assertEqual(body["filename"], "photo.png")
        self.assertEqual(body["size"], len(PNG))
        self.assertEqual(resp.headers["Location"], f"/files/{body['id']}")

        dl = self.client.get(body["download_url"], headers=self.auth())
        self.assertEqual(dl.status_code, 200)
        self.assertEqual(dl.data, PNG)
        self.assertEqual(dl.mimetype, "image/png")
        self.assertTrue(dl.headers["Content-Disposition"].startswith("attachment"))
        dl.close()

    def test_text_file_round_trip(self):
        resp = self.upload("notes.txt", "héllo wörld\n".encode())
        self.assertEqual(resp.status_code, 201)
        dl = self.client.get(resp.get_json()["download_url"], headers=self.auth())
        self.assertEqual(dl.data, "héllo wörld\n".encode())
        dl.close()

    def test_security_headers_present(self):
        resp = self.client.get("/healthz")
        self.assertEqual(resp.headers["X-Content-Type-Options"], "nosniff")
        self.assertIn("default-src 'none'", resp.headers["Content-Security-Policy"])
        self.assertEqual(resp.headers["Cache-Control"], "no-store")


class AuthTests(AppTestCase):
    def test_upload_requires_token(self):
        for token in (None, "wrong-token-wrong-token-wrong-token-1234"):
            resp = self.upload("a.png", PNG, token=token)
            self.assertEqual(resp.status_code, 401)
            self.assertEqual(resp.headers["WWW-Authenticate"], "Bearer")

    def test_download_requires_token(self):
        file_id = self.upload("a.png", PNG).get_json()["id"]
        self.assertEqual(self.client.get(f"/files/{file_id}").status_code, 401)
        bad = {"Authorization": "Bearer nope"}
        self.assertEqual(self.client.get(f"/files/{file_id}", headers=bad).status_code, 401)
        basic = {"Authorization": f"Basic {TOKEN}"}
        self.assertEqual(self.client.get(f"/files/{file_id}", headers=basic).status_code, 401)

    def test_healthz_is_public(self):
        self.assertEqual(self.client.get("/healthz").status_code, 200)


class ValidationTests(AppTestCase):
    def test_disallowed_extensions(self):
        for name in ("shell.php", "page.html", "run.exe", "noextension", ".png", "x.png.sh"):
            with self.subTest(name=name):
                self.assertEqual(self.upload(name, PNG).status_code, 415)

    def test_content_must_match_extension(self):
        self.assertEqual(self.upload("evil.png", b"<?php system($_GET[1]); ?>").status_code, 415)
        self.assertEqual(self.upload("evil.pdf", PNG).status_code, 415)

    def test_text_files_reject_binary_content(self):
        self.assertEqual(self.upload("a.txt", b"abc\x00def").status_code, 415)
        self.assertEqual(self.upload("a.csv", b"\xff\xfe\xfa").status_code, 415)

    def test_empty_file_rejected(self):
        self.assertEqual(self.upload("empty.txt", b"").status_code, 400)

    def test_missing_file_field(self):
        resp = self.client.post("/files", data={"other": "x"}, headers=self.auth())
        self.assertEqual(resp.status_code, 400)

    def test_size_limit_enforced(self):
        self.assertEqual(self.upload("big.png", PNG + b"\x00" * MAX_UPLOAD).status_code, 413)
        # Far beyond the request-level cap as well.
        self.assertEqual(self.upload("huge.png", PNG + b"\x00" * 500_000).status_code, 413)

    def test_file_exactly_at_limit_is_accepted(self):
        data = PNG + b"\x00" * (MAX_UPLOAD - len(PNG))
        self.assertEqual(self.upload("edge.png", data).status_code, 201)

    def test_rejected_uploads_leave_nothing_behind(self):
        self.upload("evil.png", b"not a png")
        self.upload("big.png", PNG + b"\x00" * MAX_UPLOAD)
        self.assertEqual(list((self.data_dir / "uploads").iterdir()), [])


class PathSafetyTests(AppTestCase):
    def test_traversal_in_filename_is_neutralised(self):
        resp = self.upload("../../../etc/evil.png", PNG)
        self.assertEqual(resp.status_code, 201)
        self.assertNotIn("/", resp.get_json()["filename"])
        self.assertNotIn("..", resp.get_json()["filename"])

        # Everything lives under DATA_DIR, and stored names are bare random IDs.
        stored = list((self.data_dir / "uploads").iterdir())
        self.assertEqual(len(stored), 1)
        self.assertRegex(stored[0].name, r"^[0-9a-f]{32}$")
        self.assertEqual({p.name for p in self.data_dir.iterdir()} - {"files.sqlite3-wal", "files.sqlite3-shm"},
                         {"uploads", "files.sqlite3"})

    def test_malformed_ids_are_404(self):
        for bad in ("..", "not-an-id", "A" * 32, "0" * 31, "0" * 33, "%2e%2e%2fetc%2fpasswd", "0" * 32):
            with self.subTest(file_id=bad):
                self.assertEqual(self.client.get(f"/files/{bad}", headers=self.auth()).status_code, 404)

    def test_files_are_private_on_disk(self):
        self.upload("a.png", PNG)
        stored = next((self.data_dir / "uploads").iterdir())
        self.assertEqual(stored.stat().st_mode & 0o777, 0o600)
        self.assertEqual((self.data_dir / "uploads").stat().st_mode & 0o777, 0o700)

    def test_missing_blob_returns_404_not_500(self):
        file_id = self.upload("a.png", PNG).get_json()["id"]
        (self.data_dir / "uploads" / file_id).unlink()
        self.assertEqual(self.client.get(f"/files/{file_id}", headers=self.auth()).status_code, 404)


class ErrorHandlingTests(AppTestCase):
    def test_errors_are_json_and_do_not_leak(self):
        resp = self.client.get("/nope")
        self.assertEqual(resp.status_code, 404)
        self.assertIn("message", resp.get_json())

    def test_method_not_allowed_includes_allow_header(self):
        resp = self.client.delete("/files/" + "0" * 32, headers=self.auth())
        self.assertEqual(resp.status_code, 405)
        self.assertIn("GET", resp.headers["Allow"])


class ConfigTests(unittest.TestCase):
    def test_requires_tokens(self):
        with tempfile.TemporaryDirectory() as d, self.assertRaises(ConfigError):
            create_app({"DATA_DIR": d, "API_TOKENS": []})

    def test_rejects_short_tokens(self):
        with tempfile.TemporaryDirectory() as d, self.assertRaises(ConfigError):
            create_app({"DATA_DIR": d, "API_TOKENS": ["short"]})

    def test_plaintext_tokens_not_kept_in_config(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app({"DATA_DIR": d, "API_TOKENS": [TOKEN]})
            self.assertNotIn("API_TOKENS", app.config)


if __name__ == "__main__":
    unittest.main()
