"""File upload/download service (application factory)."""
from __future__ import annotations

import logging
from typing import Any, Mapping

from flask import Flask, Response, jsonify
from werkzeug.exceptions import HTTPException

from .auth import digest_tokens
from .config import ConfigError, build_config
from .routes import bp
from .storage import FileStore
from .validation import UploadRejected

__all__ = ["create_app", "ConfigError"]


def create_app(overrides: Mapping[str, Any] | None = None) -> Flask:
    app = Flask(__name__)
    app.config.update(build_config(overrides))
    app.logger.setLevel(app.config["LOG_LEVEL"])

    # Keep only hashes of the tokens in the running app's config.
    app.config["API_TOKEN_DIGESTS"] = digest_tokens(app.config.pop("API_TOKENS"))

    store = FileStore(
        app.config["UPLOAD_DIR"], app.config["DATABASE"], app.config["MAX_UPLOAD_BYTES"]
    )
    store.initialize()
    app.extensions["filestore"] = store

    app.register_blueprint(bp)
    _register_error_handlers(app)
    _register_security_headers(app)
    return app


def _json_error(status: int, error: str, message: str) -> Response:
    response = jsonify(error=error, message=message)
    response.status_code = status
    return response


def _register_error_handlers(app: Flask) -> None:
    @app.errorhandler(UploadRejected)
    def handle_rejected(exc: UploadRejected) -> Response:
        return _json_error(exc.status_code, "upload_rejected", exc.message)

    @app.errorhandler(HTTPException)
    def handle_http(exc: HTTPException) -> Response:
        response = _json_error(exc.code or 500, exc.name, exc.description or "")
        for key, value in exc.get_headers():  # e.g. Allow on 405
            if key.lower() != "content-type":
                response.headers[key] = value
        if exc.code == 401:
            response.headers["WWW-Authenticate"] = "Bearer"
        return response

    @app.errorhandler(Exception)
    def handle_unexpected(exc: Exception) -> Response:
        app.logger.exception("Unhandled error")
        # Never leak internals to the client.
        return _json_error(500, "Internal Server Error", "An unexpected error occurred.")


def _register_security_headers(app: Flask) -> None:
    @app.after_request
    def add_headers(response: Response) -> Response:
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"  # responses are private
        return response
