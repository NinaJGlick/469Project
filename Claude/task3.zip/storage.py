"""Persistence: file bytes on local disk, metadata in SQLite.

Security-relevant design choices:

* Files are stored under a server-generated random ID with no extension. No
  client-controlled string ever becomes part of a filesystem path, which
  removes path traversal and overwrite risks by construction.
* Uploads stream into a private temp file and are moved into place atomically
  only after every check passes, so a partial or rejected upload is never
  visible to downloaders.
* Directories are 0700 and files 0600.
"""
from __future__ import annotations

import hashlib
import logging
import os
import re
import sqlite3
import tempfile
import time
import uuid
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO

from .validation import ALLOWED_TYPES, ContentChecker, UploadRejected

log = logging.getLogger(__name__)

CHUNK_SIZE = 64 * 1024
FILE_ID_RE = re.compile(r"[0-9a-f]{32}")  # uuid4().hex
PARTIAL_PREFIX = ".part-"
STALE_PARTIAL_SECONDS = 3600

_SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    id            TEXT PRIMARY KEY,
    original_name TEXT NOT NULL,
    content_type  TEXT NOT NULL,
    size          INTEGER NOT NULL,
    sha256        TEXT NOT NULL,
    created_at    TEXT NOT NULL
)
"""


@dataclass(frozen=True)
class StoredFile:
    id: str
    original_name: str
    content_type: str
    size: int
    sha256: str
    created_at: str


class FileStore:
    def __init__(self, upload_dir: Path, database: Path, max_bytes: int) -> None:
        self._upload_dir = Path(upload_dir)
        self._database = Path(database)
        self._max_bytes = max_bytes

    # -- setup ---------------------------------------------------------------

    def initialize(self) -> None:
        for directory in (self._database.parent, self._upload_dir):
            directory.mkdir(parents=True, exist_ok=True)
            os.chmod(directory, 0o700)
        with closing(self._connect()) as conn, conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(_SCHEMA)
        self._purge_stale_partials()

    def _purge_stale_partials(self) -> None:
        """Remove temp files left behind by crashed requests.

        Only files older than an hour are removed, so a worker starting up
        never deletes another worker's in-flight upload.
        """
        cutoff = time.time() - STALE_PARTIAL_SECONDS
        for path in self._upload_dir.glob(f"{PARTIAL_PREFIX}*"):
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink()
            except OSError:
                log.warning("Could not remove stale partial upload %s", path.name)

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._database, timeout=10)

    # -- operations ----------------------------------------------------------

    def save(self, stream: BinaryIO, display_name: str, extension: str) -> StoredFile:
        """Validate and persist an upload. Raises :class:`UploadRejected`."""
        allowed = ALLOWED_TYPES[extension]
        checker = ContentChecker(allowed)
        digest = hashlib.sha256()
        size = 0

        file_id = uuid.uuid4().hex
        destination = self.path_for(file_id)
        fd, tmp_name = tempfile.mkstemp(prefix=PARTIAL_PREFIX, dir=self._upload_dir)
        tmp_path = Path(tmp_name)  # mkstemp creates it with mode 0600
        try:
            with os.fdopen(fd, "wb") as out:
                while chunk := stream.read(CHUNK_SIZE):
                    size += len(chunk)
                    if size > self._max_bytes:
                        raise UploadRejected(
                            f"File exceeds the {self._max_bytes}-byte limit.", 413
                        )
                    checker.feed(chunk)
                    digest.update(chunk)
                    out.write(chunk)
                checker.finish()
                out.flush()
                os.fsync(out.fileno())
            os.replace(tmp_path, destination)  # atomic on the same filesystem
        except BaseException:
            tmp_path.unlink(missing_ok=True)
            raise

        record = StoredFile(
            id=file_id,
            original_name=display_name,
            content_type=allowed.content_type,
            size=size,
            sha256=digest.hexdigest(),
            created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        try:
            with closing(self._connect()) as conn, conn:
                conn.execute(
                    "INSERT INTO files VALUES (?, ?, ?, ?, ?, ?)",
                    (record.id, record.original_name, record.content_type,
                     record.size, record.sha256, record.created_at),
                )
        except sqlite3.Error:
            destination.unlink(missing_ok=True)  # don't orphan the bytes
            raise
        return record

    def get(self, file_id: str) -> StoredFile | None:
        """Look up metadata. Malformed IDs simply don't exist."""
        if not FILE_ID_RE.fullmatch(file_id):
            return None
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT id, original_name, content_type, size, sha256, created_at "
                "FROM files WHERE id = ?",
                (file_id,),
            ).fetchone()
        return StoredFile(*row) if row else None

    def path_for(self, file_id: str) -> Path:
        """Filesystem path for a *validated* ID."""
        if not FILE_ID_RE.fullmatch(file_id):
            raise ValueError("Invalid file id.")
        return self._upload_dir / file_id
