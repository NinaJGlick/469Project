"""Validation of untrusted upload metadata and content.

The client-supplied filename and Content-Type are never trusted. A file is
accepted only if its extension is on the allowlist *and* its bytes match that
type (magic number for binary formats, strict UTF-8 for text formats).
"""
from __future__ import annotations

import codecs
from dataclasses import dataclass

from werkzeug.utils import secure_filename

HEADER_BYTES = 16
MAX_FILENAME_LENGTH = 100


class UploadRejected(Exception):
    """An upload failed validation. Carries the HTTP status to return."""

    def __init__(self, message: str, status_code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


@dataclass(frozen=True)
class AllowedType:
    content_type: str
    signatures: tuple[bytes, ...] = ()
    is_text: bool = False


_JPEG = AllowedType("image/jpeg", (b"\xff\xd8\xff",))

# Deliberately small allowlist. Extend consciously: every type added is a type
# you are agreeing to store and serve.
ALLOWED_TYPES: dict[str, AllowedType] = {
    "pdf": AllowedType("application/pdf", (b"%PDF-",)),
    "png": AllowedType("image/png", (b"\x89PNG\r\n\x1a\n",)),
    "jpg": _JPEG,
    "jpeg": _JPEG,
    "gif": AllowedType("image/gif", (b"GIF87a", b"GIF89a")),
    "txt": AllowedType("text/plain", is_text=True),
    "csv": AllowedType("text/csv", is_text=True),
}


def parse_filename(raw_name: str | None) -> tuple[str, str]:
    """Return ``(display_name, extension)`` or raise :class:`UploadRejected`.

    The display name is only ever used as a download label. It is *never* used
    to build a filesystem path.
    """
    name = secure_filename(raw_name or "")
    stem, dot, extension = name.rpartition(".")
    extension = extension.lower()
    if not dot or not stem or extension not in ALLOWED_TYPES:
        allowed = ", ".join(sorted(ALLOWED_TYPES))
        raise UploadRejected(f"File type not allowed. Allowed extensions: {allowed}.", 415)
    stem = stem[: MAX_FILENAME_LENGTH - len(extension) - 1]
    return f"{stem}.{extension}", extension


def _mismatch() -> UploadRejected:
    return UploadRejected("File content does not match its extension.", 415)


class ContentChecker:
    """Incrementally validates content as it streams to disk."""

    def __init__(self, allowed: AllowedType) -> None:
        self._allowed = allowed
        self._header = b""
        self._size = 0
        self._decoder = codecs.getincrementaldecoder("utf-8")() if allowed.is_text else None

    def feed(self, chunk: bytes) -> None:
        self._size += len(chunk)
        if len(self._header) < HEADER_BYTES:
            self._header += chunk[: HEADER_BYTES - len(self._header)]
        if self._decoder is not None:
            if b"\x00" in chunk:
                raise _mismatch()
            try:
                self._decoder.decode(chunk)
            except UnicodeDecodeError:
                raise _mismatch() from None

    def finish(self) -> None:
        if self._size == 0:
            raise UploadRejected("Uploaded file is empty.", 400)
        if self._decoder is not None:
            try:
                self._decoder.decode(b"", final=True)
            except UnicodeDecodeError:
                raise _mismatch() from None
        elif not self._header.startswith(self._allowed.signatures):
            raise _mismatch()
