"""Bearer-token authentication."""
from __future__ import annotations

import hashlib
import hmac
from functools import wraps
from typing import Any, Callable, Iterable

from flask import current_app, request
from werkzeug.exceptions import Unauthorized


def digest_tokens(tokens: Iterable[str]) -> tuple[bytes, ...]:
    """Hash tokens so comparisons are constant-time and length-independent."""
    return tuple(hashlib.sha256(t.encode("utf-8")).digest() for t in tokens)


def _bearer_token() -> str | None:
    scheme, _, token = request.headers.get("Authorization", "").partition(" ")
    token = token.strip()
    if scheme.lower() != "bearer" or not token:
        return None
    return token


def _is_valid(token: str) -> bool:
    candidate = hashlib.sha256(token.encode("utf-8")).digest()
    valid = False
    # Check every known token (no early exit) to keep timing uniform.
    for known in current_app.config["API_TOKEN_DIGESTS"]:
        valid |= hmac.compare_digest(candidate, known)
    return valid


def require_auth(view: Callable[..., Any]) -> Callable[..., Any]:
    """Reject requests that lack a valid ``Authorization: Bearer <token>``."""

    @wraps(view)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        token = _bearer_token()
        if token is None or not _is_valid(token):
            raise Unauthorized("Missing or invalid credentials.")
        return view(*args, **kwargs)

    return wrapper
