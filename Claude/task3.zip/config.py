"""Application configuration.

Settings come from environment variables; ``overrides`` (used by tests) take
precedence. Validation happens at startup so a misconfigured deployment fails
immediately instead of running in an insecure state.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Iterable, Mapping

DEFAULT_MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MiB
MIN_TOKEN_LENGTH = 32
# Headroom for multipart boundaries/headers so a file exactly at the limit is
# not rejected by the request-level size cap before the store can check it.
MULTIPART_OVERHEAD_BYTES = 64 * 1024


class ConfigError(RuntimeError):
    """Raised when the application is misconfigured."""


def _parse_tokens(raw: str | Iterable[str] | None) -> tuple[str, ...]:
    if raw is None:
        return ()
    items = raw.split(",") if isinstance(raw, str) else raw
    return tuple(t.strip() for t in items if t and t.strip())


def _positive_int(value: Any, name: str) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ConfigError(f"{name} must be an integer.") from None
    if number <= 0:
        raise ConfigError(f"{name} must be greater than zero.")
    return number


def build_config(overrides: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Build and validate the Flask configuration mapping."""
    extra = dict(overrides or {})

    data_dir = Path(
        extra.pop("DATA_DIR", None) or os.environ.get("FILESHARE_DATA_DIR") or "data"
    ).resolve()

    max_upload = _positive_int(
        extra.pop("MAX_UPLOAD_BYTES", None)
        or os.environ.get("FILESHARE_MAX_UPLOAD_BYTES", DEFAULT_MAX_UPLOAD_BYTES),
        "MAX_UPLOAD_BYTES",
    )

    tokens = _parse_tokens(
        extra.pop("API_TOKENS", None) or os.environ.get("FILESHARE_API_TOKENS")
    )
    if not tokens:
        raise ConfigError(
            "FILESHARE_API_TOKENS is not set. Provide at least one token of "
            f"{MIN_TOKEN_LENGTH}+ characters (comma-separated for several)."
        )
    if any(len(t) < MIN_TOKEN_LENGTH for t in tokens):
        raise ConfigError(f"Every API token must be at least {MIN_TOKEN_LENGTH} characters.")

    config: dict[str, Any] = {
        "DATA_DIR": data_dir,
        "UPLOAD_DIR": data_dir / "uploads",
        "DATABASE": data_dir / "files.sqlite3",
        "MAX_UPLOAD_BYTES": max_upload,
        "MAX_CONTENT_LENGTH": max_upload + MULTIPART_OVERHEAD_BYTES,
        "API_TOKENS": tokens,
        "LOG_LEVEL": os.environ.get("FILESHARE_LOG_LEVEL", "INFO").upper(),
        "JSON_SORT_KEYS": False,
    }
    # Pass through anything else (e.g. TESTING) that wasn't handled above.
    config.update(extra)
    return config
