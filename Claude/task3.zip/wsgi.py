"""WSGI entry point:  gunicorn --bind 127.0.0.1:8000 wsgi:app"""
from fileshare import create_app

app = create_app()
