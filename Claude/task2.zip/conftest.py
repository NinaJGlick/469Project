import io

import pytest

from fileserver import create_app


@pytest.fixture
def upload_dir(tmp_path):
    return tmp_path / "uploads"


@pytest.fixture
def app(upload_dir):
    return create_app({"TESTING": True, "UPLOAD_FOLDER": str(upload_dir)})


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def upload(client):
    """Helper that uploads ``content`` as ``filename`` and returns the response."""

    def _upload(content=b"hello world", filename="hello.txt", field="file"):
        return client.post(
            "/files",
            data={field: (io.BytesIO(content), filename)},
            content_type="multipart/form-data",
        )

    return _upload
