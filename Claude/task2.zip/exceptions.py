"""Application-level exceptions.

Each exception carries the HTTP status code it should be reported with, so the
error handlers in :mod:`fileserver.errors` can translate them uniformly.
"""

from __future__ import annotations


class AppError(Exception):
    """Base class for errors that are safe to show to API clients."""

    status_code = 500
    default_message = "Internal server error."

    def __init__(self, message: str | None = None) -> None:
        self.message = message or self.default_message
        super().__init__(self.message)


class ValidationError(AppError):
    status_code = 400
    default_message = "The request is invalid."


class UnsupportedFileTypeError(AppError):
    status_code = 415
    default_message = "This file type is not allowed."


class StoredFileNotFoundError(AppError):
    status_code = 404
    default_message = "File not found."


class StorageError(AppError):
    """The server failed to read from or write to its file storage."""

    status_code = 500
    default_message = "The file could not be processed due to a storage error."
