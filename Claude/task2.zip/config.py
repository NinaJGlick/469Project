"""Application configuration.

Values are read from environment variables once at import time. Invalid values
(for example a non-numeric ``MAX_UPLOAD_MB``) raise immediately so that a
misconfigured deployment fails at startup rather than at request time.
"""

from __future__ import annotations

import os

_DEFAULT_ALLOWED_EXTENSIONS = "txt,pdf,png,jpg,jpeg,gif,csv,json,docx,xlsx,pptx,zip"


def _parse_extensions(raw: str) -> frozenset[str]:
    return frozenset(
        ext.strip().lower().lstrip(".") for ext in raw.split(",") if ext.strip()
    )


class Config:
    # Directory for stored files. ``None`` means "<instance_path>/uploads".
    UPLOAD_FOLDER: str | None = os.environ.get("UPLOAD_FOLDER") or None

    # Werkzeug rejects larger request bodies with HTTP 413.
    MAX_CONTENT_LENGTH: int = int(os.environ.get("MAX_UPLOAD_MB", "16")) * 1024 * 1024

    # Explicit allow-list of lowercase extensions (without the dot).
    ALLOWED_EXTENSIONS: frozenset[str] = _parse_extensions(
        os.environ.get("ALLOWED_EXTENSIONS", _DEFAULT_ALLOWED_EXTENSIONS)
    )

    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO").upper()
