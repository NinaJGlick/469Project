"""Local-disk file storage.

Design notes
------------
* Files are stored under a server-generated random ID, never under the
  client-supplied name. This rules out path traversal, name collisions and
  accidental overwrites. The original name is kept in a JSON sidecar file and
  used only for the download filename.
* Data files have a ``.bin`` suffix so a misconfigured web server can never
  treat an upload as something executable.
* Writes go to a temporary file in the same directory and are moved into place
  with :func:`os.replace`, which is atomic on POSIX and Windows. A file is only
  visible once its metadata exists, so readers never observe partial uploads.
  This also makes the store safe to use from multiple worker processes.
"""

from __future__ import annotations

import json
import logging
import mimetypes
import os
import re
import shutil
import tempfile
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, BinaryIO

from .exceptions import StorageError, StoredFileNotFoundError, ValidationError

logger = logging.getLogger(__name__)

_FILE_ID_RE = re.compile(r"[0-9a-f]{32}")
_CHUNK_SIZE = 64 * 1024
_DEFAULT_CONTENT_TYPE = "application/octet-stream"


@dataclass(frozen=True)
class StoredFile:
    """Metadata describing a stored file."""

    id: str
    original_name: str
    content_type: str
    size: int
    uploaded_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class LocalFileStore:
    """Stores uploaded files in a single local directory."""

    def __init__(self, root: str | os.PathLike[str]) -> None:
        self._root = Path(root).resolve()
        self._root.mkdir(parents=True, exist_ok=True)

    @property
    def root(self) -> Path:
        return self._root

    # ------------------------------------------------------------------ public

    def save(self, stream: BinaryIO, original_name: str) -> StoredFile:
        """Persist ``stream`` and return its metadata.

        ``original_name`` must already be sanitised by the caller; it is stored
        for display purposes only and never used to build a filesystem path.
        """
        file_id = uuid.uuid4().hex
        data_path = self._data_path(file_id)
        meta_path = self._meta_path(file_id)

        tmp_path, size = self._spool_to_temp(stream)
        try:
            if size == 0:
                raise ValidationError("The uploaded file is empty.")
            os.replace(tmp_path, data_path)
        except OSError as exc:
            logger.exception("Failed to move upload into place (id=%s)", file_id)
            raise StorageError() from exc
        finally:
            tmp_path.unlink(missing_ok=True)

        record = StoredFile(
            id=file_id,
            original_name=original_name,
            content_type=mimetypes.guess_type(original_name)[0] or _DEFAULT_CONTENT_TYPE,
            size=size,
            uploaded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )
        try:
            self._write_json(meta_path, record.to_dict())
        except OSError as exc:
            logger.exception("Failed to write metadata (id=%s)", file_id)
            data_path.unlink(missing_ok=True)  # don't leave an orphaned blob
            raise StorageError() from exc

        logger.info("Stored file id=%s size=%d", file_id, size)
        return record

    def locate(self, file_id: str) -> tuple[StoredFile, Path]:
        """Return metadata and the on-disk path for ``file_id``.

        Raises :class:`StoredFileNotFoundError` for unknown *and* malformed
        IDs, so callers cannot probe the validation rules.
        """
        if not _FILE_ID_RE.fullmatch(file_id):
            raise StoredFileNotFoundError()

        try:
            with self._meta_path(file_id).open(encoding="utf-8") as fh:
                record = StoredFile(**json.load(fh))
        except FileNotFoundError:
            raise StoredFileNotFoundError() from None
        except (OSError, ValueError, TypeError) as exc:
            logger.exception("Unreadable metadata (id=%s)", file_id)
            raise StorageError() from exc

        data_path = self._data_path(file_id)
        if not data_path.is_file():
            logger.error("Metadata exists but data is missing (id=%s)", file_id)
            raise StoredFileNotFoundError()
        return record, data_path

    # ----------------------------------------------------------------- private

    def _data_path(self, file_id: str) -> Path:
        return self._root / f"{file_id}.bin"

    def _meta_path(self, file_id: str) -> Path:
        return self._root / f"{file_id}.json"

    def _spool_to_temp(self, stream: BinaryIO) -> tuple[Path, int]:
        """Copy ``stream`` into a temp file inside the store; return (path, size)."""
        tmp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                dir=self._root, prefix=".upload-", suffix=".part", delete=False
            ) as tmp:
                tmp_path = Path(tmp.name)
                shutil.copyfileobj(stream, tmp, _CHUNK_SIZE)
                size = tmp.tell()
        except Exception as exc:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)
            if isinstance(exc, OSError):
                logger.exception("Failed to write upload to disk")
                raise StorageError() from exc
            raise
        return tmp_path, size

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        tmp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self._root,
                prefix=".meta-",
                suffix=".part",
                delete=False,
            ) as fh:
                tmp_path = Path(fh.name)
                json.dump(payload, fh)
            os.replace(tmp_path, path)
        except Exception:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)
            raise
