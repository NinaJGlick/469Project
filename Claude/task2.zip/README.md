# Flask File Service

Upload files to local disk and download them again by ID.

## Run

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements-dev.txt
    pytest
    flask --app wsgi run --debug                        # development
    gunicorn --workers 4 --bind 0.0.0.0:8000 wsgi:app   # production

## API

| Method | Path          | Description                                   |
|--------|---------------|-----------------------------------------------|
| POST   | `/files`      | Upload (multipart field `file`) -> 201 + JSON |
| GET    | `/files/<id>` | Download as attachment under original name    |
| GET    | `/health`     | Liveness probe                                |

    curl -F "file=@report.pdf" http://localhost:8000/files
    curl -OJ http://localhost:8000/files/<id>

Errors are JSON: `{"error": {"status": 415, "message": "..."}}`.
Statuses: 400 invalid request, 404 unknown id, 413 too large, 415 type not allowed.

## Configuration (environment variables)

| Variable             | Default                   | Meaning                          |
|----------------------|---------------------------|----------------------------------|
| `UPLOAD_FOLDER`      | `<instance>/uploads`      | Where files are stored           |
| `MAX_UPLOAD_MB`      | `16`                      | Maximum request size             |
| `ALLOWED_EXTENSIONS` | txt,pdf,png,jpg,... (see `config.py`) | Comma-separated allow-list |
| `LOG_LEVEL`          | `INFO`                    | Python log level                 |

## Security and operations notes

- Files are stored under random IDs (`<id>.bin` + `<id>.json` metadata); the client
  filename is sanitised and used only for the download name.
- Downloads are always `Content-Disposition: attachment` with `nosniff`.
- Extension checks are not content verification. Add magic-byte checks or virus
  scanning if you accept untrusted files.
- There is no authentication: anyone with an ID can download. Put the service
  behind auth (or a reverse proxy) before exposing it, and also cap request size
  at the proxy (e.g. nginx `client_max_body_size`).
- Add a retention/cleanup job if disk usage matters.
