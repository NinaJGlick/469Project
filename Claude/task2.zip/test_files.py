import io


def test_upload_then_download_round_trip(client, upload):
    resp = upload(b"some bytes", "report.txt")

    assert resp.status_code == 201
    body = resp.get_json()
    assert body["original_name"] == "report.txt"
    assert body["size"] == len(b"some bytes")
    assert resp.headers["Location"] == f"/files/{body['id']}"

    download = client.get(resp.headers["Location"])
    assert download.status_code == 200
    assert download.data == b"some bytes"
    disposition = download.headers["Content-Disposition"]
    assert "attachment" in disposition and "report.txt" in disposition
    assert download.headers["X-Content-Type-Options"] == "nosniff"


def test_storage_layout_has_no_leftover_temp_files(upload, upload_dir):
    upload()
    assert sorted(p.suffix for p in upload_dir.iterdir()) == [".bin", ".json"]


def test_client_filename_cannot_escape_upload_dir(client, upload, upload_dir):
    resp = upload(b"x", "../../evil.txt")

    assert resp.status_code == 201
    assert resp.get_json()["original_name"] == "evil.txt"
    assert not (upload_dir.parent.parent / "evil.txt").exists()
    assert all(p.parent == upload_dir for p in upload_dir.iterdir())


def test_missing_file_field_is_rejected(client):
    resp = client.post("/files", data={}, content_type="multipart/form-data")
    assert resp.status_code == 400
    assert resp.get_json()["error"]["status"] == 400


def test_wrong_field_name_is_rejected(upload):
    assert upload(field="document").status_code == 400


def test_empty_filename_is_rejected(client):
    resp = client.post(
        "/files",
        data={"file": (io.BytesIO(b"x"), "")},
        content_type="multipart/form-data",
    )
    assert resp.status_code == 400


def test_disallowed_extension_is_rejected(upload, upload_dir):
    resp = upload(b"#!/bin/sh", "script.sh")
    assert resp.status_code == 415
    assert list(upload_dir.iterdir()) == []


def test_filename_without_extension_is_rejected(upload):
    assert upload(b"x", "README").status_code == 400


def test_empty_file_is_rejected_and_nothing_is_stored(upload, upload_dir):
    resp = upload(b"", "empty.txt")
    assert resp.status_code == 400
    assert list(upload_dir.iterdir()) == []


def test_oversized_upload_returns_413(upload_dir):
    from fileserver import create_app

    app = create_app(
        {"TESTING": True, "UPLOAD_FOLDER": str(upload_dir), "MAX_CONTENT_LENGTH": 10}
    )
    resp = app.test_client().post(
        "/files",
        data={"file": (io.BytesIO(b"x" * 1000), "big.txt")},
        content_type="multipart/form-data",
    )
    assert resp.status_code == 413
    assert "size limit" in resp.get_json()["error"]["message"]


def test_unknown_id_returns_404(client):
    resp = client.get("/files/" + "a" * 32)
    assert resp.status_code == 404
    assert resp.get_json()["error"]["message"] == "File not found."


def test_malformed_ids_return_404(client):
    for bad_id in ("..", "not-a-uuid", "A" * 32, "..%2F..%2Fetc%2Fpasswd"):
        assert client.get(f"/files/{bad_id}").status_code == 404


def test_download_404s_when_blob_is_missing(client, upload, upload_dir):
    file_id = upload().get_json()["id"]
    (upload_dir / f"{file_id}.bin").unlink()
    assert client.get(f"/files/{file_id}").status_code == 404


def test_method_not_allowed_is_json(client):
    resp = client.delete("/files/" + "a" * 32)
    assert resp.status_code == 405
    assert resp.get_json()["error"]["status"] == 405


def test_health(client):
    assert client.get("/health").get_json() == {"status": "ok"}
