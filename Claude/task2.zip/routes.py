"""HTTP endpoints.

POST /files        Upload a file (multipart/form-data, field name ``file``).
GET  /files/<id>   Download a previously uploaded file.
GET  /health       Liveness probe.
"""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, send_file, url_for
from flask import request
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from .exceptions import UnsupportedFileTypeError, ValidationError
from .storage import LocalFileStore

bp = Blueprint("files", __name__)

_UPLOAD_FIELD = "file"


def _store() -> LocalFileStore:
    return current_app.extensions["file_store"]


def _validated_filename(upload: FileStorage) -> str:
    """Return a sanitised filename, or raise if the upload is unacceptable."""
    if not upload.filename:
        raise ValidationError("No file was selected.")

    filename = secure_filename(upload.filename)
    if not filename or "." not in filename:
        raise ValidationError("The filename is invalid or has no extension.")

    extension = filename.rsplit(".", 1)[1].lower()
    allowed = current_app.config["ALLOWED_EXTENSIONS"]
    if extension not in allowed:
        raise UnsupportedFileTypeError(
            f"Files of type '.{extension}' are not allowed. "
            f"Allowed types: {', '.join(sorted(allowed))}."
        )
    return filename


@bp.post("/files")
def upload_file():
    upload = request.files.get(_UPLOAD_FIELD)
    if upload is None:
        raise ValidationError(
            f"Missing file: send a multipart/form-data field named '{_UPLOAD_FIELD}'."
        )

    filename = _validated_filename(upload)
    record = _store().save(upload.stream, filename)

    response = jsonify(record.to_dict())
    response.status_code = 201
    response.headers["Location"] = url_for("files.download_file", file_id=record.id)
    return response


@bp.get("/files/<file_id>")
def download_file(file_id: str):
    record, path = _store().locate(file_id)
    return send_file(
        path,
        as_attachment=True,  # never render uploaded content inline
        download_name=record.original_name,
        mimetype=record.content_type,
    )


@bp.get("/health")
def health():
    return jsonify({"status": "ok"})
