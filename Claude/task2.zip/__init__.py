"""File upload/download service."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping

from flask import Flask

from .config import Config
from .errors import register_error_handlers, register_security_headers
from .routes import bp as files_bp
from .storage import LocalFileStore


def create_app(config_overrides: Mapping[str, Any] | None = None) -> Flask:
    """Application factory.

    ``config_overrides`` takes precedence over environment-based config, which
    keeps tests isolated from the real environment.
    """
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)
    if config_overrides:
        app.config.update(config_overrides)

    logging.basicConfig(
        level=app.config["LOG_LEVEL"],
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    upload_folder = app.config["UPLOAD_FOLDER"] or Path(app.instance_path) / "uploads"
    app.extensions["file_store"] = LocalFileStore(upload_folder)

    app.register_blueprint(files_bp)
    register_error_handlers(app)
    register_security_headers(app)
    return app
