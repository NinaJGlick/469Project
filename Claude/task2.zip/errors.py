"""Error handling: every failure is returned as a consistent JSON body.

    {"error": {"status": 404, "message": "File not found."}}
"""

from __future__ import annotations

import logging

from flask import Flask, Response, jsonify
from werkzeug.exceptions import HTTPException, RequestEntityTooLarge

from .exceptions import AppError

logger = logging.getLogger(__name__)


def _error_response(status: int, message: str) -> tuple[Response, int]:
    return jsonify({"error": {"status": status, "message": message}}), status


def register_error_handlers(app: Flask) -> None:
    @app.errorhandler(AppError)
    def handle_app_error(err: AppError):
        return _error_response(err.status_code, err.message)

    @app.errorhandler(RequestEntityTooLarge)
    def handle_too_large(_err: RequestEntityTooLarge):
        limit_mb = app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024)
        return _error_response(413, f"The upload exceeds the {limit_mb} MB size limit.")

    @app.errorhandler(HTTPException)
    def handle_http_exception(err: HTTPException):
        return _error_response(err.code or 500, err.description or err.name)

    @app.errorhandler(Exception)
    def handle_unexpected(err: Exception):
        # Log the details server-side; never leak them to the client.
        logger.exception("Unhandled exception", exc_info=err)
        return _error_response(500, "Internal server error.")


def register_security_headers(app: Flask) -> None:
    @app.after_request
    def add_security_headers(response: Response) -> Response:
        # Stop browsers from MIME-sniffing downloaded content into something active.
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        return response
