"""WSGI entry point.

Production:  gunicorn --workers 4 --bind 0.0.0.0:8000 wsgi:app
Development: flask --app wsgi run --debug
"""

from fileserver import create_app

app = create_app()
