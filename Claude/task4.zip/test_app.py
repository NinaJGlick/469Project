import io
import os
import re
from pathlib import Path

import pytest

from fileservice import create_app
from fileservice.config import ConfigError, Settings

ALICE = "a" * 40
BOB = "b" * 40
PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
MAX_BYTES = 4096


@pytest.fixture
def upload_root(tmp_path: Path) -> Path:
    return tmp_path / "uploads"


@pytest.fixture
def client(upload_root: Path):
    settings = Settings.from_env(
        {
            "FILESERVICE_API_TOKENS": f"alice:{ALICE},bob:{BOB}",
            "FILESERVICE_UPLOAD_DIR": str(upload_root),
            "FILESERVICE_MAX_UPLOAD_BYTES": str(MAX_BYTES),
        }
    )
    app = create_app(settings)
    app.testing = True
    return app.test_client()


def auth(token: str = ALICE) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def upload(client, name: str, data: bytes, token: str = ALICE):
    return client.post(
        "/files",
        data={"file": (io.BytesIO(data), name)},
        headers=auth(token),
        content_type="multipart/form-data",
    )


def all_files(root: Path) -> list[Path]:
    return [p for p in root.rglob("*") if p.is_file()]


# --------------------------------------------------------------- happy path
def test_upload_and_download_roundtrip(client):
    resp = upload(client, "Quarterly Report.txt", b"hello world")
    assert resp.status_code == 201
    body = resp.get_json()
    assert body["filename"] == "Quarterly_Report.txt"
    assert body["size"] == 11

    dl = client.get(body["download_url"], headers=auth())
    assert dl.status_code == 200
    assert dl.data == b"hello world"
    assert dl.headers["Content-Disposition"].startswith("attachment")
    assert dl.headers["X-Content-Type-Options"] == "nosniff"
    assert dl.mimetype == "text/plain"


def test_binary_types_accepted_with_valid_signature(client):
    assert upload(client, "pic.png", PNG).status_code == 201
    assert upload(client, "doc.pdf", b"%PDF-1.7\n...").status_code == 201


def test_listing_only_shows_own_files(client):
    upload(client, "a.txt", b"alice file")
    upload(client, "b.txt", b"bob file", token=BOB)
    names = [f["filename"] for f in client.get("/files", headers=auth()).get_json()["files"]]
    assert names == ["a.txt"]


def test_same_filename_never_overwrites(client):
    first = upload(client, "same.txt", b"one").get_json()
    second = upload(client, "same.txt", b"two").get_json()
    assert first["id"] != second["id"]
    assert client.get(first["download_url"], headers=auth()).data == b"one"
    assert client.get(second["download_url"], headers=auth()).data == b"two"


# ------------------------------------------------------------ authentication
@pytest.mark.parametrize("headers", [{}, {"Authorization": "Bearer nope"}, {"Authorization": "Basic abc"}])
def test_endpoints_require_valid_token(client, headers):
    assert client.get("/files", headers=headers).status_code == 401
    assert client.get("/files/" + "0" * 32, headers=headers).status_code == 401
    resp = client.post("/files", data={"file": (io.BytesIO(b"x"), "x.txt")}, headers=headers)
    assert resp.status_code == 401
    assert resp.headers["WWW-Authenticate"] == "Bearer"


def test_cannot_download_another_users_file(client):
    file_id = upload(client, "secret.txt", b"classified").get_json()["id"]
    resp = client.get(f"/files/{file_id}", headers=auth(BOB))
    assert resp.status_code == 404
    assert b"classified" not in resp.data


# ------------------------------------------------------------ path traversal
@pytest.mark.parametrize(
    "name",
    ["../../evil.txt", "..\\..\\evil.txt", "/etc/cron.d/evil.txt", "a/b/c/evil.txt", "..%2f..%2fevil.txt"],
)
def test_traversal_in_upload_filename_stays_inside_owner_dir(client, upload_root, name):
    assert upload(client, name, b"data").status_code == 201
    root = upload_root.resolve()
    for path in all_files(upload_root):
        assert path.resolve().parent == (root / "alice")
        assert re.fullmatch(r"[0-9a-f]{32}\.(txt|json)", path.name)  # nothing user-controlled
    assert not (upload_root.parent / "evil.txt").exists()


@pytest.mark.parametrize(
    "file_id",
    ["..%2f..%2fetc%2fpasswd", "....//....//etc/passwd", "%2e%2e%2f", "not-a-valid-id", "A" * 32, "0" * 31, "0" * 33],
)
def test_traversal_in_download_id_is_rejected(client, file_id):
    resp = client.get(f"/files/{file_id}", headers=auth())
    assert resp.status_code == 404
    assert b"/" not in resp.get_json()["error"]["message"].encode()


# ------------------------------------------------------ type / size / content
@pytest.mark.parametrize("name", ["shell.php", "run.exe", "page.html", "image.svg", "noext", ".txt", "x.txt.sh"])
def test_disallowed_or_missing_extensions_rejected(client, upload_root, name):
    assert upload(client, name, b"hello").status_code in (400, 415)
    assert all_files(upload_root) == []


def test_content_must_match_extension(client, upload_root):
    resp = upload(client, "fake.png", b"MZ\x90\x00 this is really an exe")
    assert resp.status_code == 400
    assert all_files(upload_root) == []  # partial file cleaned up


def test_text_files_must_be_valid_utf8_without_nul(client):
    assert upload(client, "bad.txt", b"\xff\xfe\xfd").status_code == 400
    assert upload(client, "nul.csv", b"a,b\x00,c").status_code == 400
    assert upload(client, "ok.csv", "naïve,café\n".encode()).status_code == 201


def test_empty_file_rejected(client):
    assert upload(client, "empty.txt", b"").status_code == 400


def test_per_file_size_limit_enforced(client, upload_root):
    assert upload(client, "ok.txt", b"a" * MAX_BYTES).status_code == 201
    over = upload(client, "big.txt", b"a" * (MAX_BYTES + 1))
    assert over.status_code == 413
    assert len(all_files(upload_root)) == 2  # only the accepted file (+ its metadata)


def test_request_body_limit_enforced_by_flask(client):
    assert upload(client, "huge.txt", b"a" * (MAX_BYTES + 200_000)).status_code == 413


def test_exactly_one_file_required(client):
    resp = client.post("/files", data={}, headers=auth(), content_type="multipart/form-data")
    assert resp.status_code == 400
    resp = client.post(
        "/files",
        data={"file": [(io.BytesIO(b"1"), "1.txt"), (io.BytesIO(b"2"), "2.txt")]},
        headers=auth(),
        content_type="multipart/form-data",
    )
    assert resp.status_code == 400


# --------------------------------------------------------- error disclosure
def test_unexpected_errors_do_not_leak_internals(client, upload_root, monkeypatch):
    def boom(*args, **kwargs):
        raise RuntimeError(f"secret detail at {upload_root}")

    monkeypatch.setattr("fileservice.storage.FileStore.save", boom)
    client.application.testing = False  # behave like production
    resp = upload(client, "a.txt", b"x")
    assert resp.status_code == 500
    text = resp.get_data(as_text=True)
    assert str(upload_root) not in text
    assert "secret detail" not in text
    assert "Traceback" not in text
    assert resp.get_json()["error"]["request_id"]


def test_404_and_405_are_json_without_paths(client):
    assert client.get("/nope").get_json()["error"]["status"] == 404
    resp = client.delete("/files", headers=auth())
    assert resp.status_code == 405
    assert "Allow" in resp.headers


# ------------------------------------------------------------ configuration
def test_refuses_to_start_without_tokens():
    with pytest.raises(ConfigError):
        Settings.from_env({})


@pytest.mark.parametrize(
    "raw",
    ["alice:short", "alice", "Bad Owner:" + "x" * 40, f"a:{'x' * 40},a:{'y' * 40}", f"a:{'x' * 40},b:{'x' * 40}"],
)
def test_weak_or_invalid_token_config_rejected(raw):
    with pytest.raises(ConfigError) as info:
        Settings.from_env({"FILESERVICE_API_TOKENS": raw})
    assert "xxxxxxxx" not in str(info.value)  # tokens never echoed


def test_refuses_to_start_in_debug_mode(monkeypatch, tmp_path):
    monkeypatch.setenv("FLASK_DEBUG", "1")
    settings = Settings.from_env(
        {"FILESERVICE_API_TOKENS": f"alice:{ALICE}", "FILESERVICE_UPLOAD_DIR": str(tmp_path)}
    )
    with pytest.raises(ConfigError):
        create_app(settings)


@pytest.mark.skipif(os.name != "posix", reason="POSIX permissions only")
def test_stored_files_are_private(client, upload_root):
    upload(client, "a.txt", b"x")
    for path in all_files(upload_root):
        assert path.stat().st_mode & 0o077 == 0
