# Secure File Service

A small Flask API to upload files to a local directory and download them again,
built around secure-by-default file handling.

## Endpoints

All endpoints except `/health` require `Authorization: Bearer <token>`.

| Method | Path            | Description                                             |
|--------|-----------------|---------------------------------------------------------|
| POST   | `/files`        | Upload one file (multipart field `file`) → `201` + JSON |
| GET    | `/files`        | List your uploaded files                                |
| GET    | `/files/<id>`   | Download one of your files (always as an attachment)    |
| GET    | `/health`       | Liveness check (no auth)                                |

```bash
curl -H "Authorization: Bearer $TOKEN" -F "file=@report.pdf" https://host/files
curl -H "Authorization: Bearer $TOKEN" -OJ https://host/files/<id>
```

Allowed types: `.txt .csv .pdf .png .jpg .jpeg .gif` (edit `ALLOWED_TYPES` in
`fileservice/storage.py`; add a magic-number entry for any binary type you add).

## Run

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt

export FILESERVICE_API_TOKENS="alice:$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
export FILESERVICE_UPLOAD_DIR=/var/lib/fileservice/uploads   # optional

gunicorn --bind 127.0.0.1:8000 --workers 4 wsgi:app
```

Put it behind a TLS-terminating reverse proxy (nginx, Caddy, ...). Bearer tokens
are only safe over HTTPS. Also set a body limit there (e.g. nginx
`client_max_body_size`) and rate limiting. See `.env.example` for all settings.
The app refuses to start if tokens are missing/weak or if `FLASK_DEBUG` is set.

## Tests

```bash
pip install -r requirements-dev.txt
pytest
```

## How each security requirement is met

| Requirement | Implementation |
|---|---|
| Directory traversal | User filenames are **never used as filesystem paths**. Files are stored as `<owner>/<uuid4>.<ext>`; download is by a 32-hex ID validated with a strict regex. Resolved paths are checked to sit directly inside the owner directory, and `send_from_directory` adds Werkzeug's `safe_join`. |
| Filename sanitising | `secure_filename()`; result must have a stem and an allowlisted extension; length-capped. Used only as display/download name. |
| Extension allowlist + size cap | `ALLOWED_TYPES` (explicit). `MAX_CONTENT_LENGTH` rejects oversized bodies early; the exact per-file limit is enforced while streaming, so it doesn't depend on `Content-Length`. Partial files are deleted on failure. |
| Content validation | Magic numbers for PDF/PNG/JPEG/GIF; strict UTF-8 and no NUL bytes for text/CSV. |
| No overwrites | Random IDs plus exclusive creation (`O_CREAT\|O_EXCL`), so existing files can't be replaced. Same-named uploads become separate files. |
| No execution / shell | Uploaded files are only ever written and streamed; no `subprocess`, `os.system`, or dynamic imports anywhere. Files are mode `0600`. |
| Authorization | Bearer-token auth (constant-time compare, tokens held only as SHA-256 digests in memory). Each token maps to an owner with a private directory. Another owner's ID returns the same `404` as a missing one. |
| Safe serving | `Content-Disposition: attachment`, MIME type from the server allowlist (not the client), `X-Content-Type-Options: nosniff`, restrictive CSP, `Cache-Control: no-store`. |
| Error handling | JSON errors only. Unexpected exceptions are logged server-side with a request ID; clients get a generic message and the ID. |
| Debug mode | No `app.run()` anywhere; `create_app()` raises if debug is enabled. |
| No hardcoded secrets | All configuration comes from environment variables. Tokens are never logged or echoed in config errors. |

## Known limitations / hardening ideas

* Magic-number checks confirm a file *starts* like its type; they don't prove it
  is benign (polyglots, malicious PDFs). Consider antivirus scanning (e.g.
  ClamAV) or re-encoding images with Pillow if files are served to others.
* No per-user quotas or rate limiting in-app; do this at the proxy or add
  Flask-Limiter. Monitor disk usage.
* Listing scans the owner's directory (capped at 1000 results). For large
  volumes, move metadata to a database.
* Static tokens suit service-to-service use. For end users, swap `auth.py` for
  your identity provider (OIDC/JWT); the rest of the app only needs `g.owner`.
* Back up the upload directory and keep it on a volume that is not web-served
  and mounted `noexec`.
