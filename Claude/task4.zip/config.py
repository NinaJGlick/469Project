"""Application settings, loaded exclusively from environment variables.

Nothing sensitive is hardcoded. The service refuses to start if its
configuration is missing or weak, rather than silently running insecurely.

Environment variables
---------------------
FILESERVICE_API_TOKENS      Required. Comma-separated ``owner:token`` pairs,
                            e.g. ``alice:<random>,bob:<random>``.
FILESERVICE_UPLOAD_DIR      Optional. Directory for stored files
                            (default: ``<project>/instance/uploads``).
FILESERVICE_MAX_UPLOAD_BYTES Optional. Per-file size limit (default: 10 MiB).
"""
from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

# Owner names become directory names, so they are restricted to a safe charset.
OWNER_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")

MIN_TOKEN_LENGTH = 32
DEFAULT_MAX_UPLOAD_BYTES = 10 * 1024 * 1024
ABSOLUTE_MAX_UPLOAD_BYTES = 1024 * 1024 * 1024
DEFAULT_UPLOAD_DIR = Path(__file__).resolve().parent.parent / "instance" / "uploads"


class ConfigError(RuntimeError):
    """Raised when the application is misconfigured."""


@dataclass(frozen=True)
class Settings:
    upload_root: Path
    max_upload_bytes: int
    # (sha256(token), owner). Only digests are kept in memory after startup.
    token_digests: tuple[tuple[bytes, str], ...]

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Settings":
        env = os.environ if env is None else env

        raw_tokens = env.get("FILESERVICE_API_TOKENS", "")
        if not raw_tokens.strip():
            raise ConfigError(
                "FILESERVICE_API_TOKENS is not set. Provide at least one "
                "'owner:token' pair (see .env.example)."
            )

        upload_dir = env.get("FILESERVICE_UPLOAD_DIR")
        upload_root = Path(upload_dir).expanduser() if upload_dir else DEFAULT_UPLOAD_DIR

        return cls(
            upload_root=upload_root,
            max_upload_bytes=_parse_max_bytes(env.get("FILESERVICE_MAX_UPLOAD_BYTES")),
            token_digests=_parse_tokens(raw_tokens),
        )


def _parse_max_bytes(raw: str | None) -> int:
    if raw is None or not raw.strip():
        return DEFAULT_MAX_UPLOAD_BYTES
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError("FILESERVICE_MAX_UPLOAD_BYTES must be an integer.") from None
    if not 0 < value <= ABSOLUTE_MAX_UPLOAD_BYTES:
        raise ConfigError(
            f"FILESERVICE_MAX_UPLOAD_BYTES must be between 1 and {ABSOLUTE_MAX_UPLOAD_BYTES}."
        )
    return value


def _parse_tokens(raw: str) -> tuple[tuple[bytes, str], ...]:
    entries: list[tuple[bytes, str]] = []
    owners: set[str] = set()
    digests: set[bytes] = set()

    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        owner, separator, token = item.partition(":")
        owner, token = owner.strip(), token.strip()

        if not separator:
            raise ConfigError("Each FILESERVICE_API_TOKENS entry must be 'owner:token'.")
        if not OWNER_PATTERN.fullmatch(owner):
            raise ConfigError(
                f"Invalid owner name {owner!r}: use 1-32 chars of a-z, 0-9, '_' or '-'."
            )
        if len(token) < MIN_TOKEN_LENGTH:
            # Never echo the token itself in an error message.
            raise ConfigError(
                f"The token for owner {owner!r} is shorter than {MIN_TOKEN_LENGTH} characters."
            )

        digest = hashlib.sha256(token.encode("utf-8")).digest()
        if owner in owners:
            raise ConfigError(f"Duplicate owner {owner!r} in FILESERVICE_API_TOKENS.")
        if digest in digests:
            raise ConfigError("Two owners share the same token; tokens must be unique.")
        owners.add(owner)
        digests.add(digest)
        entries.append((digest, owner))

    if not entries:
        raise ConfigError("FILESERVICE_API_TOKENS contains no valid entries.")
    return tuple(entries)
