"""Safe file storage.

Design decisions that make the common file-upload attacks structurally hard:

* **User-supplied filenames never touch the filesystem.** Files are stored as
  ``<uuid4>.<allowlisted-ext>``. The sanitised original name is kept only as
  metadata and used as the download name. Directory traversal through a
  filename is therefore impossible, not merely filtered.
* **Per-owner directories** (``<root>/<owner>/``) so one user can never address
  another user's files, regardless of what ID they guess.
* **Exclusive creation** (``O_CREAT | O_EXCL``) so an existing file can never be
  overwritten, even in the astronomically unlikely event of an ID collision.
* **Extension allowlist + content checks** (magic numbers / UTF-8 validation).
* **Streaming size enforcement** independent of the ``Content-Length`` header.
* Files are created with mode ``0600`` and are never executed or passed to a
  shell.
"""
from __future__ import annotations

import codecs
import hashlib
import json
import logging
import os
import re
import uuid
from dataclasses import asdict, dataclass, fields
from datetime import datetime, timezone
from pathlib import Path

from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from .config import OWNER_PATTERN
from .errors import ApiError

logger = logging.getLogger(__name__)

CHUNK_SIZE = 64 * 1024
MAX_DISPLAY_NAME_LENGTH = 100
MAX_LIST_RESULTS = 1000

# Explicit allowlist: extension -> MIME type used when serving the file.
# The Content-Type of a download is derived from this table, never from the
# client-supplied Content-Type header.
ALLOWED_TYPES: dict[str, str] = {
    "txt": "text/plain",
    "csv": "text/csv",
    "pdf": "application/pdf",
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "gif": "image/gif",
}

# Magic numbers each binary type must start with.
_SIGNATURES: dict[str, tuple[bytes, ...]] = {
    "pdf": (b"%PDF-",),
    "png": (b"\x89PNG\r\n\x1a\n",),
    "jpg": (b"\xff\xd8\xff",),
    "jpeg": (b"\xff\xd8\xff",),
    "gif": (b"GIF87a", b"GIF89a"),
}
_TEXT_EXTENSIONS = frozenset({"txt", "csv"})

FILE_ID_PATTERN = re.compile(r"^[0-9a-f]{32}$")
_STORED_NAME_PATTERN = re.compile(r"^([0-9a-f]{32})\.([a-z0-9]{1,5})$")
_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)


def _not_found() -> ApiError:
    # The same response for "missing", "not yours" and "malformed id", so the
    # API never reveals whether a file exists for someone else.
    return ApiError(404, "File not found.")


@dataclass(frozen=True)
class StoredFile:
    file_id: str
    original_name: str
    stored_name: str
    size: int
    sha256: str
    uploaded_at: str

    @property
    def content_type(self) -> str:
        return ALLOWED_TYPES[self.stored_name.rsplit(".", 1)[1]]

    def to_public(self) -> dict[str, object]:
        return {
            "id": self.file_id,
            "filename": self.original_name,
            "size": self.size,
            "content_type": self.content_type,
            "sha256": self.sha256,
            "uploaded_at": self.uploaded_at,
        }


class _ContentValidator:
    """Incrementally verifies that file bytes match the declared extension."""

    def __init__(self, extension: str) -> None:
        self._extension = extension
        self._signatures = _SIGNATURES.get(extension)
        self._decoder = (
            codecs.getincrementaldecoder("utf-8")()
            if extension in _TEXT_EXTENSIONS
            else None
        )
        self._seen_first_chunk = False

    def _reject(self) -> ApiError:
        return ApiError(400, f"File content does not match the '.{self._extension}' type.")

    def feed(self, chunk: bytes) -> None:
        if not self._seen_first_chunk:
            self._seen_first_chunk = True
            if self._signatures and not chunk.startswith(self._signatures):
                raise self._reject()
        if self._decoder is not None:
            if b"\x00" in chunk:
                raise self._reject()
            try:
                self._decoder.decode(chunk)
            except UnicodeDecodeError:
                raise self._reject() from None

    def finish(self) -> None:
        if self._decoder is not None:
            try:
                self._decoder.decode(b"", final=True)  # catches truncated sequences
            except UnicodeDecodeError:
                raise self._reject() from None


def _discard(*paths: Path) -> None:
    for path in paths:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            logger.warning("Could not remove partial file %s", path.name)


class FileStore:
    def __init__(self, root: Path, max_bytes: int) -> None:
        self._root = Path(root).resolve()
        self._max_bytes = max_bytes
        self._root.mkdir(mode=0o700, parents=True, exist_ok=True)

    # ------------------------------------------------------------------ paths
    def _owner_dir(self, owner: str, *, create: bool = False) -> Path:
        if not OWNER_PATTERN.fullmatch(owner):
            raise ValueError("Invalid owner identifier.")
        path = (self._root / owner).resolve()
        if path.parent != self._root:  # defence in depth; cannot happen with the regex
            raise ValueError("Owner directory escapes the upload root.")
        if create:
            path.mkdir(mode=0o700, exist_ok=True)
        return path

    # ------------------------------------------------------------- validation
    @staticmethod
    def _validate_filename(raw: str | None) -> tuple[str, str]:
        """Return ``(display_name, extension)`` or raise ``ApiError``."""
        safe = secure_filename(raw or "")  # strips path parts, separators, NULs, etc.
        stem, dot, extension = safe.rpartition(".")
        extension = extension.lower()
        if not dot or not stem:
            raise ApiError(400, "A filename with an extension is required.")
        if extension not in ALLOWED_TYPES:
            allowed = ", ".join(f".{ext}" for ext in sorted(ALLOWED_TYPES))
            raise ApiError(415, f"File type not allowed. Allowed types: {allowed}.")
        stem = stem[: MAX_DISPLAY_NAME_LENGTH - len(extension) - 1]
        return f"{stem}.{extension}", extension

    # ------------------------------------------------------------------ save
    def save(self, upload: FileStorage, owner: str) -> StoredFile:
        display_name, extension = self._validate_filename(upload.filename)

        file_id = uuid.uuid4().hex
        owner_dir = self._owner_dir(owner, create=True)
        data_path = owner_dir / f"{file_id}.{extension}"
        meta_path = owner_dir / f"{file_id}.json"

        validator = _ContentValidator(extension)
        digest = hashlib.sha256()
        size = 0

        # O_EXCL: fail rather than overwrite. Opened *before* the try-block so a
        # collision can never cause us to delete somebody else's file.
        fd = os.open(data_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, "wb") as out:
                while chunk := upload.stream.read(CHUNK_SIZE):
                    size += len(chunk)
                    if size > self._max_bytes:
                        raise ApiError(
                            413, f"File exceeds the maximum size of {self._max_bytes} bytes."
                        )
                    validator.feed(chunk)
                    digest.update(chunk)
                    out.write(chunk)
            if size == 0:
                raise ApiError(400, "The uploaded file is empty.")
            validator.finish()

            record = StoredFile(
                file_id=file_id,
                original_name=display_name,
                stored_name=data_path.name,
                size=size,
                sha256=digest.hexdigest(),
                uploaded_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            )
            self._write_metadata(meta_path, record)
        except BaseException:
            _discard(data_path, meta_path)
            raise

        return record

    @staticmethod
    def _write_metadata(path: Path, record: StoredFile) -> None:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(asdict(record), handle)

    # ------------------------------------------------------------------ read
    def _load_record(self, owner: str, file_id: str) -> StoredFile:
        if not FILE_ID_PATTERN.fullmatch(file_id):
            raise _not_found()
        meta_path = self._owner_dir(owner) / f"{file_id}.json"
        try:
            with meta_path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            record = StoredFile(**{f.name: raw[f.name] for f in fields(StoredFile)})
            match = _STORED_NAME_PATTERN.fullmatch(record.stored_name)
            if (
                match is None
                or match.group(1) != file_id
                or match.group(2) not in ALLOWED_TYPES
                or not isinstance(record.original_name, str)
                or not isinstance(record.size, int)
            ):
                raise ValueError("Inconsistent metadata")
        except FileNotFoundError:
            raise _not_found() from None
        except (OSError, ValueError, KeyError, TypeError):
            logger.error("Unreadable or inconsistent metadata for file %s", file_id)
            raise _not_found() from None
        return record

    def locate(self, owner: str, file_id: str) -> tuple[Path, StoredFile]:
        """Return ``(directory, record)`` for a file owned by ``owner``.

        The stored name comes from server-written metadata and is re-validated;
        the resolved path must be a regular file directly inside the owner's
        directory (this also rejects symlinks that point elsewhere).
        """
        record = self._load_record(owner, file_id)
        directory = self._owner_dir(owner)
        path = (directory / record.stored_name).resolve()
        if path.parent != directory or not path.is_file():
            raise _not_found()
        return directory, record

    def list_files(self, owner: str) -> list[StoredFile]:
        owner_dir = self._owner_dir(owner)
        if not owner_dir.is_dir():
            return []
        records: list[StoredFile] = []
        for meta_path in owner_dir.glob("*.json"):
            try:
                records.append(self._load_record(owner, meta_path.stem))
            except ApiError:
                continue  # skip anything unreadable or inconsistent
        records.sort(key=lambda r: r.uploaded_at, reverse=True)
        return records[:MAX_LIST_RESULTS]
