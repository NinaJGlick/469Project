"""Bearer-token authentication.

Every token maps to an *owner*. Owners can only ever see their own files, which
is enforced structurally by the storage layer (one directory per owner).
"""
from __future__ import annotations

import hashlib
import hmac
from functools import wraps
from typing import Callable, Sequence, TypeVar

from flask import current_app, g, request

from .errors import ApiError

F = TypeVar("F", bound=Callable)

_MAX_TOKEN_LENGTH = 512
_CHALLENGE = {"WWW-Authenticate": "Bearer"}


def _owner_for_token(token: str, digests: Sequence[tuple[bytes, str]]) -> str | None:
    candidate = hashlib.sha256(token.encode("utf-8")).digest()
    matched: str | None = None
    # Compare against every entry (no early exit) using a constant-time compare.
    for digest, owner in digests:
        if hmac.compare_digest(candidate, digest):
            matched = owner
    return matched


def require_auth(view: F) -> F:
    """Reject the request unless it carries a valid ``Authorization: Bearer`` token."""

    @wraps(view)
    def wrapper(*args, **kwargs):
        scheme, _, token = request.headers.get("Authorization", "").partition(" ")
        token = token.strip()
        if scheme.lower() != "bearer" or not token or len(token) > _MAX_TOKEN_LENGTH:
            raise ApiError(401, "Authentication required.", _CHALLENGE)

        settings = current_app.extensions["settings"]
        owner = _owner_for_token(token, settings.token_digests)
        if owner is None:
            raise ApiError(401, "Authentication required.", _CHALLENGE)

        g.owner = owner
        return view(*args, **kwargs)

    return wrapper  # type: ignore[return-value]
