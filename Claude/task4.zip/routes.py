"""HTTP endpoints."""
from __future__ import annotations

from flask import Blueprint, current_app, g, jsonify, request, send_from_directory, url_for
from flask import Response

from .auth import require_auth
from .errors import ApiError
from .storage import FileStore, StoredFile

bp = Blueprint("files", __name__)


def _store() -> FileStore:
    return current_app.extensions["file_store"]


def _public(record: StoredFile) -> dict[str, object]:
    body = record.to_public()
    body["download_url"] = url_for("files.download_file", file_id=record.file_id)
    return body


@bp.get("/health")
def health() -> Response:
    return jsonify(status="ok")


@bp.post("/files")
@require_auth
def upload_file() -> tuple[Response, int, dict[str, str]]:
    """Upload exactly one file in the multipart field ``file``."""
    uploads = request.files.getlist("file")
    if len(uploads) != 1:
        raise ApiError(400, "Send exactly one file in the multipart form field 'file'.")

    record = _store().save(uploads[0], g.owner)
    current_app.logger.info(
        "Stored file id=%s owner=%s size=%d request_id=%s",
        record.file_id, g.owner, record.size, g.request_id,
    )
    body = _public(record)
    return jsonify(body), 201, {"Location": body["download_url"]}  # type: ignore[dict-item]


@bp.get("/files")
@require_auth
def list_files() -> Response:
    """List the authenticated owner's files."""
    return jsonify(files=[_public(record) for record in _store().list_files(g.owner)])


@bp.get("/files/<file_id>")
@require_auth
def download_file(file_id: str) -> Response:
    """Download one of the authenticated owner's files as an attachment."""
    directory, record = _store().locate(g.owner, file_id)
    return send_from_directory(
        directory,
        record.stored_name,
        mimetype=record.content_type,   # from our allowlist, never from the client
        as_attachment=True,             # never rendered inline by the browser
        download_name=record.original_name,
        max_age=0,
    )
