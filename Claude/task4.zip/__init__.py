"""Secure file upload/download service (Flask application factory)."""
from __future__ import annotations

import logging
import uuid

from flask import Flask, Response, g

from .config import ConfigError, Settings
from .errors import register_error_handlers
from .routes import bp
from .storage import FileStore

# Allowance for multipart boundaries and headers on top of the file-size limit.
_MULTIPART_OVERHEAD = 64 * 1024


def create_app(settings: Settings | None = None) -> Flask:
    app = Flask(__name__)

    # Never run with the debugger / reloader: it exposes an interactive console
    # and stack traces. Fail loudly instead of silently serving them.
    if app.debug:
        raise ConfigError(
            "Flask debug mode is enabled (FLASK_DEBUG). This service refuses to "
            "start in debug mode; unset FLASK_DEBUG."
        )

    settings = settings or Settings.from_env()
    app.logger.setLevel(logging.INFO)

    app.config.update(
        # Reject oversized request bodies early; the storage layer additionally
        # enforces the exact per-file limit while streaming.
        MAX_CONTENT_LENGTH=settings.max_upload_bytes + _MULTIPART_OVERHEAD,
        MAX_FORM_PARTS=20,
        MAX_FORM_MEMORY_SIZE=64 * 1024,
        JSON_AS_ASCII=True,
    )

    app.extensions["settings"] = settings
    app.extensions["file_store"] = FileStore(settings.upload_root, settings.max_upload_bytes)

    register_error_handlers(app)
    app.register_blueprint(bp)

    @app.before_request
    def assign_request_id() -> None:
        g.request_id = uuid.uuid4().hex[:12]

    @app.after_request
    def set_security_headers(response: Response) -> Response:
        response.headers["X-Request-ID"] = g.get("request_id", "")
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; frame-ancestors 'none'; sandbox"
        )
        response.headers["Cache-Control"] = "no-store"  # responses are per-user
        return response

    return app
