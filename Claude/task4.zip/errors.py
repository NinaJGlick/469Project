"""Uniform JSON error responses that never expose internals.

Unexpected exceptions are logged server-side (with a request id) and the client
only ever receives a generic message, so stack traces, filesystem paths and
configuration values cannot leak.
"""
from __future__ import annotations

from typing import Mapping

from flask import Flask, Response, g, jsonify
from werkzeug.exceptions import HTTPException


class ApiError(Exception):
    """An error whose message is safe to show to the client."""

    def __init__(
        self,
        status_code: int,
        message: str,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.headers = dict(headers or {})


def _json_error(
    status_code: int, message: str, headers: Mapping[str, str] | None = None
) -> Response:
    response = jsonify(
        error={
            "status": status_code,
            "message": message,
            "request_id": g.get("request_id"),
        }
    )
    response.status_code = status_code
    for name, value in (headers or {}).items():
        response.headers[name] = value
    return response


def register_error_handlers(app: Flask) -> None:
    @app.errorhandler(ApiError)
    def handle_api_error(exc: ApiError) -> Response:
        return _json_error(exc.status_code, exc.message, exc.headers)

    @app.errorhandler(HTTPException)
    def handle_http_exception(exc: HTTPException) -> Response:
        status = exc.code or 500
        message = (
            "The request body exceeds the maximum allowed size."
            if status == 413
            else exc.description or exc.name
        )
        # Keep protocol headers such as ``Allow`` on 405, drop the HTML content type.
        headers = {
            name: value
            for name, value in exc.get_headers()
            if name.lower() != "content-type"
        }
        return _json_error(status, message, headers)

    @app.errorhandler(Exception)
    def handle_unexpected(exc: Exception) -> Response:
        # Full details go to the server log only.
        app.logger.exception("Unhandled error (request_id=%s)", g.get("request_id"))
        return _json_error(500, "An internal error occurred.")
