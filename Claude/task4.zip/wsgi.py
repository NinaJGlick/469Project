"""WSGI entry point for production servers, e.g.:

    gunicorn --bind 127.0.0.1:8000 --workers 4 wsgi:app

There is intentionally no ``app.run()`` here: Flask's built-in development
server must not be used in production.
"""
from fileservice import create_app

app = create_app()
